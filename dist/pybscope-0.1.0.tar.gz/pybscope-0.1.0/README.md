# pybscope
Pybscope is an extension pack for pybricks.

## Installation
### Linux
```bash
curl https://raw.githubusercontent.com/leon8326-nogeese/pybscope/main/installer.sh | bash
```

### Other platforms
```sh
pip install pybscope
```

## License
This project is licensed under the Nogeese Public License 1.0 (NPL 1.0).  
See the [LICENSE](https://github.com/leon8326-nogeese/pybscope/blob/main/LICENSE) file for details.
